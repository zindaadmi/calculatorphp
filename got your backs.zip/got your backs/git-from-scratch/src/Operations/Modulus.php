<?php

namespace Calculator\Operations;

/**
 * @author Hanvesh Pinapothu<hanvesh.pinapothu@mpokket.com>
 */
class Modulus
{

}
