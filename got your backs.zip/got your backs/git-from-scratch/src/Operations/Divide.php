<?php

namespace Calculator\Operations;

/**
 * @author Rajesh Kamisetti <kamisetti.rajesh@mpokket.com>
 */
class Divide
{

}