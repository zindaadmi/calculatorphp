# git-from-scratch

By Got Your Backs

## Usage

`php index.php <operation> <param1> <param2> <param2> ...`

### Exponent

To get the exponent value for a number,

```
Syntax: `php index.php exponent number number`
Example `php index.php exponent 2 3`
The above example will print `8`
```

### Percentage

To get the percentage of the number

```
Syntax: `php index.php percentage number fraction of number`
Example `php index.php percentage 100 25`
The above example will print `25`
```
